Order ID: 1001
Customer ID: 123
Product ID: 456
Product Name: Alpine Skis
Quantity Ordered: 1
Price: $499.99
Total Price: $499.99
Date: 2023-10-15

Order ID: 1002
Customer ID: 456
Product ID: 789
Product Name: Thermal Gloves
Quantity Ordered: 2
Price: $59.99
Total Price: $119.98
Date: 2023-10-16

Order ID: 1003
Customer ID: 789
Product ID: 101
Product Name: Carbon Fiber Poles
Quantity Ordered: 1
Price: $89.99
Total Price: $89.99
Date: 2023-10-17

Order ID: 1004
Customer ID: 101
Product ID: 112
Product Name: Ski Goggles
Quantity Ordered: 1
Price: $129.99
Total Price: $129.99
Date: 2023-10-18

Order ID: 1005
Customer ID: 112
Product ID: 131
Product Name: Insulated Jacket
Quantity Ordered: 1
Price: $199.99
Total Price: $199.99
Date: 2023-10-19

Order ID: 1006
Customer ID: 234
Product ID: 567
Product Name: Performance Racing Skis
Quantity Ordered: 1
Price: $799.99
Total Price: $799.99
Date: 2023-10-20

Order ID: 1007
Customer ID: 345
Product ID: 678
Product Name: Pro Ski Boots
Quantity Ordered: 1
Price: $449.99
Total Price: $449.99
Date: 2023-10-21

Order ID: 1008
Customer ID: 456
Product ID: 789
Product Name: Mountain Series Helmet
Quantity Ordered: 2
Price: $179.99
Total Price: $359.98
Date: 2023-10-22

Order ID: 1009
Customer ID: 567
Product ID: 890
Product Name: Alpine Base Layer
Quantity Ordered: 3
Price: $89.99
Total Price: $269.97
Date: 2023-10-23

Order ID: 1010
Customer ID: 678
Product ID: 901
Product Name: Avalanche Safety Pack
Quantity Ordered: 1
Price: $699.99
Total Price: $699.99
Date: 2023-10-24

Order ID: 1011
Customer ID: 789
Product ID: 912
Product Name: Performance Racing Skis
Quantity Ordered: 1
Price: $799.99
Total Price: $799.99
Date: 2023-10-25

Order ID: 1012
Customer ID: 890
Product ID: 923
Product Name: Pro Ski Boots
Quantity Ordered: 1
Price: $449.99
Total Price: $449.99
Date: 2023-10-25

Order ID: 1013
Customer ID: 901
Product ID: 934
Product Name: Alpine Skis
Quantity Ordered: 1
Price: $499.99
Total Price: $499.99
Date: 2023-10-26

Order ID: 1014
Customer ID: 912
Product ID: 945
Product Name: Thermal Gloves
Quantity Ordered: 2
Price: $59.99
Total Price: $119.98
Date: 2023-10-27

Order ID: 1015
Customer ID: 923
Product ID: 956
Product Name: Carbon Fiber Poles
Quantity Ordered: 2
Price: $89.99
Total Price: $179.98
Date: 2023-10-28

Order ID: 1016
Customer ID: 934
Product ID: 967
Product Name: Ski Goggles
Quantity Ordered: 1
Price: $129.99
Total Price: $129.99
Date: 2023-10-29

Order ID: 1017
Customer ID: 945
Product ID: 978
Product Name: Mountain Series Helmet
Quantity Ordered: 1
Price: $179.99
Total Price: $179.99
Date: 2023-10-30

Order ID: 1018
Customer ID: 956
Product ID: 989
Product Name: Alpine Base Layer
Quantity Ordered: 2
Price: $89.99
Total Price: $179.98
Date: 2023-10-31

Order ID: 1019
Customer ID: 967
Product ID: 990
Product Name: Avalanche Safety Pack
Quantity Ordered: 1
Price: $699.99
Total Price: $699.99
Date: 2023-11-01

Order ID: 1020
Customer ID: 978
Product ID: 991
Product Name: Performance Racing Skis
Quantity Ordered: 1
Price: $799.99
Total Price: $799.99
Date: 2023-11-02

Order ID: 1021
Customer ID: 989
Product ID: 992
Product Name: Pro Ski Boots
Quantity Ordered: 1
Price: $449.99
Total Price: $449.99
Date: 2023-11-03

Order ID: 1022
Customer ID: 990
Product ID: 993
Product Name: Insulated Jacket
Quantity Ordered: 2
Price: $199.99
Total Price: $399.98
Date: 2023-11-04

Order ID: 1023
Customer ID: 991
Product ID: 994
Product Name: Alpine Skis
Quantity Ordered: 1
Price: $499.99
Total Price: $499.99
Date: 2023-11-05

Order ID: 1024
Customer ID: 992
Product ID: 995
Product Name: Mountain Series Helmet
Quantity Ordered: 1
Price: $179.99
Total Price: $179.99
Date: 2023-11-06

Order ID: 1025
Customer ID: 993
Product ID: 996
Product Name: Thermal Gloves
Quantity Ordered: 3
Price: $59.99
Total Price: $179.97
Date: 2023-11-07