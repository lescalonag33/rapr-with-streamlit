---
name: DLAI Issue Template
about: You can use this template to add the required info for your issue.
title: 'Mx item-name: issue-in-one-line'
labels: ''
assignees: ''

---

**1. Item link -**


**2. Specific Issue Area -** (Eg - Timestamps/Screenshots/Code Snippet/Quiz number/Assignment File) -


**3. Label -** Pick a label from each of these four categories _Item, Priority, Type & Stage_.


**4. Description -** 


**5. Proposed Solution (if any) -**
